package com.instantnote.cloud
class NoteRepository {
    fun getDefaultNotes(): List<String> = listOf("Build via GitHub Actions", "Export APK")
}
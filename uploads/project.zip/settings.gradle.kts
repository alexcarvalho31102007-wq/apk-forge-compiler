rootProject.name = "InstantNoteApp"
include(":app")